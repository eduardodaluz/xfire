/*
 * $Id: CharWriter.java,v 1.5 2004/11/03 15:14:21 vm147297 Exp $
 * $Revision: 1.5 $
 * $Date: 2004/11/03 15:14:21 $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.xml.messaging.saaj.util;

import java.io.CharArrayWriter;

// This class just gives access to the underlying buffer without copying.

public class CharWriter extends CharArrayWriter {
    public CharWriter () {
        super();
    }
        
    public CharWriter(int size) {
        super(size);
    }
        
    public char[] getChars() {
        return buf;
    }
    
    public int getCount() {
        return count;
    }
}
