/*
 * $Id: CharReader.java,v 1.5 2004/11/03 15:14:21 vm147297 Exp $
 * $Revision: 1.5 $
 * $Date: 2004/11/03 15:14:21 $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.xml.messaging.saaj.util;

import java.io.CharArrayReader;

// This class just gives access to the underlying buffer without copying.

public class CharReader extends CharArrayReader {
    public CharReader(char buf[], int length) {
        super(buf, 0, length);
    }

    public CharReader(char buf[], int offset, int length) {
        super(buf, offset, length);
    }
        
    public char[] getChars() {
        return buf;
    }

    public int getCount() {
        return count;
    }
}
