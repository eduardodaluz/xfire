/*
 * $Id: SOAPDocument.java,v 1.4 2004/04/02 01:25:11 ofung Exp $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
*
* @author SAAJ RI Development Team
*/
package com.sun.xml.messaging.saaj.soap;

public interface SOAPDocument {
    SOAPPartImpl getSOAPPart();
    SOAPDocumentImpl getDocument();
}