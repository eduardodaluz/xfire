/*
 * $Id: TreeException.java,v 1.4 2004/04/02 01:25:14 ofung Exp $
 * $Revision: 1.4 $
 * $Date: 2004/04/02 01:25:14 $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.xml.messaging.saaj.soap.impl;

public class TreeException extends RuntimeException {
    public TreeException(String reason) {
        super(reason);
    }
}
