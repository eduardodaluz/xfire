/*
 * $Id: SOAPDocumentFragment.java,v 1.5 2004/11/03 10:55:49 vm147297 Exp $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
*
* @author SAAJ RI Development Team
*/
package com.sun.xml.messaging.saaj.soap;

import com.sun.org.apache.xerces.internal.dom.CoreDocumentImpl;
import com.sun.org.apache.xerces.internal.dom.DocumentFragmentImpl;

public class SOAPDocumentFragment extends DocumentFragmentImpl {

    public SOAPDocumentFragment(CoreDocumentImpl ownerDoc) {
        super(ownerDoc);
    }

    public SOAPDocumentFragment() {
        super();
    }

}
