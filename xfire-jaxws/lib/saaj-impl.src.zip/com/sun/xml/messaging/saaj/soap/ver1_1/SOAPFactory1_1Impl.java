/*
 * $Id: SOAPFactory1_1Impl.java,v 1.3 2005/06/22 10:14:33 vj135062 Exp $
 */

/*
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
*
* @author SAAJ RI Development Team
*/
package com.sun.xml.messaging.saaj.soap.ver1_1;

import javax.xml.soap.Detail;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;

import javax.xml.namespace.QName;

import com.sun.xml.messaging.saaj.soap.SOAPDocumentImpl;
import com.sun.xml.messaging.saaj.soap.SOAPFactoryImpl;

public class SOAPFactory1_1Impl extends SOAPFactoryImpl {
    protected SOAPDocumentImpl createDocument() {
        return (new SOAPPart1_1Impl()).getDocument();
    }

    public Detail createDetail() throws SOAPException {
        return new Detail1_1Impl(createDocument());
    }

    public SOAPFault createFault(String reasonText, QName faultCode) 
        throws SOAPException {
        Fault1_1Impl fault = new Fault1_1Impl(createDocument(), null);
        fault.setFaultString(reasonText);
        fault.setFaultCode(faultCode);
        return fault;
    }

    public SOAPFault createFault() throws SOAPException {
        Fault1_1Impl fault = new Fault1_1Impl(createDocument(), null);
        fault.setFaultCode(fault.getDefaultFaultCode());
        fault.setFaultString("Fault string, and possibly fault code, not set");
        return fault;
    }
}
