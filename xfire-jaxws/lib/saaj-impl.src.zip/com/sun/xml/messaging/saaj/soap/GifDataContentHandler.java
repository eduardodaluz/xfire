/*
 * $Id: GifDataContentHandler.java,v 1.13 2005/10/24 18:08:44 mk125090 Exp $
 * $Revision: 1.13 $
 * $Date: 2005/10/24 18:08:44 $
 */

/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package com.sun.xml.messaging.saaj.soap;

import java.awt.datatransfer.DataFlavor;
import java.io.*;
import com.sun.image.codec.jpeg.*;

import java.awt.image.BufferedImage;
import java.awt.*;
import java.awt.MediaTracker;

import javax.activation.*;

/**
 * DataContentHandler for image/gif.
 *
 * @author Ana Lindstrom-Tamer
 */
public class GifDataContentHandler extends Component implements DataContentHandler {
    private static ActivationDataFlavor myDF =
        new ActivationDataFlavor(
            java.awt.Image.class,
            "image/gif",
            "GIF Image");

    protected ActivationDataFlavor getDF() {
        return myDF;
    }

    /**
     * Return the DataFlavors for this <code>DataContentHandler</code>.
     *
     * @return The DataFlavors
     */
    public DataFlavor[] getTransferDataFlavors() { // throws Exception;
        return new DataFlavor[] { getDF()};
    }

    /**
     * Return the Transfer Data of type DataFlavor from InputStream.
     *
     * @param df The DataFlavor
     * @param ins The InputStream corresponding to the data
     * @return String object
     */
    public Object getTransferData(DataFlavor df, DataSource ds)
        throws IOException {
        // use myDF.equals to be sure to get ActivationDataFlavor.equals,
        // which properly ignores Content-Type parameters in comparison
        if (getDF().equals(df))
            return getContent(ds);
        else
            return null;
    }

    public Object getContent(DataSource ds) throws IOException {
        InputStream is = ds.getInputStream();
        int pos = 0;
        int count;
        byte buf[] = new byte[1024];

        while ((count = is.read(buf, pos, 1024)) != -1) {
            pos += count;
            byte tbuf[] = new byte[pos + 1024];
            System.arraycopy(buf, 0, tbuf, 0, pos);
            buf = tbuf;
        }
        Toolkit tk = Toolkit.getDefaultToolkit();
        return tk.createImage(buf, 0, pos);
    }

    /*
    public Object getContent(DataSource ds) { // throws Exception;
        InputStream inputStream = null;
        JPEGImageDecoder decoder = null;
        BufferedImage jpegLoadImage = null;

        try {
            inputStream = ds.getInputStream();
            decoder = JPEGCodec.createJPEGDecoder(inputStream);
            jpegLoadImage = decoder.decodeAsBufferedImage();

        } catch (Exception e) {
        }

        return (Image) jpegLoadImage;
    }
    */
    
    /**
     * Write the object to the output stream, using the specified MIME type.
     */
    /*
    public void writeTo(Object obj, String type, OutputStream os)
        throws IOException {
        if (!(obj instanceof Image)) 
            throw new IOException(
                "\""
                    + getDF().getMimeType()
                    + "\" DataContentHandler requires Image object, "
                    + "was given object of type "
                    + obj.getClass().toString());

        throw new IOException("GIF encoding not supported");
    }
    */
    public void writeTo(Object obj, String mimeType, OutputStream os)
        throws IOException {
        if (!mimeType.equals("image/gif"))
            throw new IOException(
                "Invalid content type \""
                    + mimeType
                    + "\" for ImageContentHandler");

        if (obj.equals(null)) {
            throw new IOException("Null object for ImageContentHandler");
        }

        try {
            BufferedImage bufImage = null;
            if (obj instanceof BufferedImage) {
                bufImage = (BufferedImage) obj;

            } else {
                Image img = (Image) obj;
                MediaTracker tracker = new MediaTracker(this);
                tracker.addImage(img, 0);
                tracker.waitForAll();
                if (tracker.isErrorAny()) {
			throw new IOException("Error while loading image");
		}
                bufImage =
                    new BufferedImage(
                        img.getWidth(null),
                        img.getHeight(null),
                        BufferedImage.TYPE_INT_RGB);

                Graphics g = bufImage.createGraphics();
                g.drawImage(img, 0, 0, null);
            }

            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(os);
            JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bufImage);
            param.setQuality(1, false);
            encoder.encode(bufImage, param);

        } catch (Exception ex) {
            throw new IOException(
                "Unable to run the Encoder on a GIF stream "
                    + ex.getMessage());
        }
    }

}
